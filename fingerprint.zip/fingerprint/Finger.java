import java.util.*;
import java.io.*;
class Finger{
 	public static String fileopen(String s)throws FileNotFoundException   
	{                     //it is use for fileopening and raise the filenot found exception
		int c=0;
		File  file = new File(s);
		String s1="";
		try                                
		{
			Scanner sc= new Scanner(file);
		    while(sc.hasNextLine())
		    {
		      s1+=sc.nextLine();
		      s1=s1.replace("\n"," "); 
		      c=c+1;
		    }
		    sc.close();
		}
		catch(Exception e)
		{
		    e.printStackTrace(); 
		}

		return s1;
  	}
  	public static String specialcharacter(String s) 
  	{														// it is use for remove the special character
  		s=s.toLowerCase();
		int r=0;
		String data=""; 
    	int a=s.length();
    	while(r<a)
    	{
        if((s.charAt(r)==32) || (s.charAt(r)>=65 && s.charAt(r)<=90) || (s.charAt(r)>=97 && s.charAt(r)<=122) || (s.charAt(r)>=47 && s.charAt(r)<=58))
        {
            data=data+s.charAt(r);
        }
        r++;
    }  
    return data;
	}
	public static double[] Weights(String s,int k){  // it is use for divide the characters  according to anagram value and convert char to asccii and mutiply and sum the values
		int i=0,l=0;
		double sum=0;
		double []b=new double[s.length()-k];
		while((i+k)<s.length()){
			if(s.substring(i,i+k).length()==k){
				String a =s.substring(i,i+k);
				//System.out.println(a);
				int t=k;
				for(int j=0;j<k;j++){
					int n=(int)a.charAt(j);
					sum=sum+(n*Math.pow(2,t-1));
					t--;
				}
				b[l]=sum;
				l++;
			}
			i++;
				
		}
		return b;
	}
	public static double hash_count(double []r,double []v){       // it is use for count the same value
		double count=0;
		for(int i=0;i<r.length;i++){
			for(int j=0;j<v.length;j++){
				if(r[i]==v[j]){
					count=count+1;
				}

			}
		}
		return count;
	}
	public static void display(String re[],double c[][],int i){  // it is use for display the matrix
			for(int u=0;u<i;u++)
			{
				
	    	System.out.print("	"+re[u]+"  ");
	   		 }
	   		 System.out.println("\n");

			for(int t=0;t<c.length;t++)
	   		 {                               
	   		  	System.out.print(re[t]);
	   		  	for(int n=0;n<c.length;n++)
	   		  	{
	   		  		System.out.print("  "+c[t][n]+"  ");
	   		  	}
	   		  	System.out.println("\n");

			}
	}
 }
