import java.util.*;
import java.io.*;
 public class Fingerprint{
	public static void main(String[] args)throws FileNotFoundException,NegativeArraySizeException {
		try{
			Finger obj=new Finger(); //create the new object
			Scanner sc=new Scanner(System.in);
			String path=args[0];
			File folder = new File(path);
			int i=0;
			File[] listOfFiles = folder.listFiles();        //reading the files          
			String re[]=new String[listOfFiles.length];
			for (int p = 0; p < listOfFiles.length; p++) {
			  File file = listOfFiles[p];
			  if (file.getName().endsWith(".txt")) {
				  re[i]=file.getName();
				  i++;
			  } 
			}
			double c[][]=new double[i][i];
			int k=Integer.parseInt(sc.nextLine());  // take tha anagram value

			for(int t=0;t<i;t++)
	   		 {                                
	   		  	//System.out.print(re[t]);
	   		  	for(int n=0;n<i;n++)
	   		  	{
	   		  		if(re[t]!=re[n])
	   		  		{
	   		  			String ch1;
	   		  			String ch2;
	   		  			ch1=obj.fileopen(re[t]);  //call for fileopening function
	                	ch2=obj.fileopen(re[n]);
	                 	String p=obj.specialcharacter(ch1).replace(" ","");  //call for specialcharacter function and  replace the space with without space
						String q=obj.specialcharacter(ch2).replace(" ","");
						double[] r=obj.Weights(p,k);  //call for weights function
						double[] v=obj.Weights(q,k); 
						double w=r.length+v.length;  //calculate the length of arrays
						double u=obj.hash_count(r,v);  //call the hash_count function
						double z=((2*u)/w)*100;  //percentage of files
						double roundOff=Math.round(z*100)/100.0;  //round the values
						c[t][n]=roundOff;  //values enter to array
					}
					else{
						c[t][n]=00.00;   //two files same then print 00.00
					}
				}
			}
			 obj.display(re,c,i);  //call for display function
		}catch(NegativeArraySizeException ex)
		{
			System.out.println("empty file");   // one file is empty then print one file is empty
		}
	}
}