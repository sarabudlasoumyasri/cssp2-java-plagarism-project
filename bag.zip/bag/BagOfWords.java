import java.util.*;
import java.io.*;
public class BagOfWords{	
public static void main(String[] args)throws FileNotFoundException {
	try{
			Bag obj =new Bag();	 // create the new object						
			Scanner sc=new Scanner(System.in);
			String path=args[0];
			File folder = new File(path);
			int i=0;
			File[] listOfFiles = folder.listFiles();          // files reading  and try catch is use for rasie the FileNotFoundException
			String re[]=new String[listOfFiles.length];
			for (int p = 0; p < listOfFiles.length; p++) {
			  File file = listOfFiles[p];
			  if (file.getName().endsWith(".txt")) {
				  re[i]=file.getName();
				  i++;
			  } 
			}
			double c[][]=new double[i][i];     // take the new array
	   		  for(int t=0;t<i;t++)
	   		 {                                
	   		  	//System.out.print(re[t]);
	   		  	for(int n=0;n<i;n++)
	   		  	{
	   		  		if(re[t]!=re[n])
	   		  		{
	   		  			String ch1;
	   		  			String ch2;
	   		  			ch1=obj.fileopen(re[t]);     // call the file open function
	   		           	ch2=obj.fileopen(re[n]);
	                 	String p=obj.specialcharacter(ch1);   // call the specialcharacter function
						String q=obj.specialcharacter(ch2);
						String []x=new String[100];
						String []y=new String[100];    // two new arrays
						x=p.split(" ");
						y=q.split(" ");
						HashMap<String,Integer> d=obj.freq_words(x);   //call the freq_words function
						HashMap<String,Integer> e=obj.freq_words(y);
						int f=obj.dot_product(d,e);    //call the dot_product function
						int g=obj.deno(d);     //call the deno function
						int h=obj.deno(e);
						double l=Math.sqrt(g*h);  //mutiply the files and squareroot
						double m=(f/l)*100;   // percentage of files
						double roundOff=Math.round(m*100)/100.0;  // roundoff the values
						c[t][n]=roundOff; //values are enter to array  	
					}
					else{
					
						c[t][n]=00.00;  //two files same then print 00.00
					}
				}
			}	
			obj.display(re,c,i);   //call the display function
		}catch(Fileempty e)   
		{
			System.out.println("one file is empty");    //if one isfiles empty then print one file is empty
		}		
	}
}
