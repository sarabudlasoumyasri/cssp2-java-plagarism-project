import java.util.*;
import java.io.*;
class Fileempty extends Exception{ //create the new error
	//String s;
	public Fileempty(String message){
		super(message);
	}
}
class lcs{
	public static String fileopen(String s)throws FileNotFoundException
	{                       // it is use for fileopening and raise the filenotfoundexception
		int c=0;
		File  file = new File(s);
		String s1="";
		try                               
		{
			Scanner sc= new Scanner(file);
		    while(sc.hasNextLine())
		    {
		      s1+=sc.nextLine();
		      s1=s1.replace("\n"," "); 
		      c=c+1;
		    }
		    sc.close();
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		}

		return s1;
  	}
  	public static String specialcharacter(String s)throws Fileempty  
  	{	if(s.length()==0){               //it is use for remove the special character and raise the fileempaty error
			throw new Fileempty("one file is empty");
		}
  		s=s.toLowerCase();
		int r=0;
		String data=""; 
    	int a=s.length();
    	while(r<a)
    	{
        if((s.charAt(r)==32) || (s.charAt(r)>=65 && s.charAt(r)<=90) || (s.charAt(r)>=97 && s.charAt(r)<=122) || (s.charAt(r)>=47 && s.charAt(r)<=58))
        {
            data=data+s.charAt(r);
        }
        r++;
    }  
    return data;
	}
	public static float lcs_count(String p,String q)  
	{
		float c=0; //it is use for count the large common string and print the large word
		for(int i=0;i<p.length();i++){
			int x=i;
			int y=x;
			for(int j=0;j<q.length();j++){
				if(x<p.length()){
					if(p.charAt(x)==q.charAt(j)){
						x++;
						if((x-i)>c){
						c=x-i;
						String t=p.substring(i,x);
						//System.out.println(t);

						}
					}
					else
					{
						x=y;
					}
			    }

			}
		}
	return c;
	}
	public static void display(String re[],double c[][],int i){
			for(int u=0;u<i;u++)             //it is use for display the matrix
			{
				
	    	System.out.print("	"+re[u]+"  ");
	   		 }
	   		 System.out.println("\n");

			for(int t=0;t<c.length;t++)
	   		 {                               
	   		  	System.out.print(re[t]);
	   		  	for(int n=0;n<c.length;n++)
	   		  	{
	   		  		System.out.print("  "+c[t][n]+"  ");
	   		  	}
	   		  	System.out.println("\n");

			}

	}
}