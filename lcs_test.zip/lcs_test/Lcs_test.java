import java.util.*;
import java.io.*;
public class Lcs_test{	
public static void main(String[] args)throws FileNotFoundException{
	try{
			lcs obj=new lcs();   //create the new object
			Scanner sc=new Scanner(System.in);
			String path=args[0];
			File folder = new File(path);
			int i=0;
			File[] listOfFiles = folder.listFiles();        //reading files
			String re[]=new String[listOfFiles.length];
			for (int p = 0; p < listOfFiles.length; p++) {
			  File file = listOfFiles[p];
			  if (file.getName().endsWith(".txt")) {
				  re[i]=file.getName();
				  i++;
			  } 
			}
			double c[][]=new double[i][i];
			
	   		for(int t=0;t<i;t++)
	   		 {                                
	   		  	//System.out.print(re[t]);
	   		  	for(int n=0;n<i;n++)
	   		  	{
	   		  		if(re[t]!=re[n])
	   		  		{
	   		  			String ch1;
	   		  			String ch2;
	   		  			ch1=obj.fileopen(re[t]);      //call the file open function
	                	ch2=obj.fileopen(re[n]);
	                 	String p=obj.specialcharacter(ch1);//call the specialcharacter function
						String q=obj.specialcharacter(ch2);
						double k;
						if(p.length()>q.length()){    
						 k=obj.lcs_count(p,q); //call the lcs_count function
						}
						else{
							k=obj.lcs_count(q,p);
						}
						double y=(p.length()+q.length());  //calculate the length of files
						double z=((2*k)/y)*100; //percentage of files
						double roundOff=Math.round(z*100)/100.0; //round the values
						c[t][n]=roundOff; // values enter to array
	             	}
	             	else{
	             		c[t][n]=00.00; // two files are same print 00.00
	            	}
	            }
	            
	        }
	        obj.display(re,c,i);
	    }catch(Fileempty e)
		{
			System.out.println("one file is empty");  // one file is empty then print one file is empty
		}		
    }
	
}